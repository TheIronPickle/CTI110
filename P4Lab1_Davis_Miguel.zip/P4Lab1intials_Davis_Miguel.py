#Miguel Davis
#11/2/2024
#P4Lab1
#Drawing my initials with turtle

import turtle

# Set up teh screen
screen = turtle.Screen()

# Set up the turtle
t = turtle.Turtle()
t.pensize(2)
t.color("green")
t.speed(3)

# Draw letter M
t.penup()
t.goto(-100, 0)
t.pendown()
t.left(90)
t.forward(100)
t.right(135)
t.forward(71)
t.left(90)
t.forward(71)
t.right(135)
t.forward(100)

# Draw letter D
t.penup()
t.goto(20, 0)
t.setheading(90)
t.pendown()
t.forward(100)
t.right(90)
t.circle(-50, 180)

# Hide turtle and exit
t.hideturtle()
screen.exitonclick()