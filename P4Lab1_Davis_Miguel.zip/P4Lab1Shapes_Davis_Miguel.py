#Miguel Davis
#11/2/2024
#P4Lab1
#Drawing triangle and square with turtle

import turtle
t = turtle.Turtle()

for i in range(4):
    t.forward(100)
    t.right(90)

for i in range(3):
    t.forward(100)
    t.left(120)

turtle.exitonclick()